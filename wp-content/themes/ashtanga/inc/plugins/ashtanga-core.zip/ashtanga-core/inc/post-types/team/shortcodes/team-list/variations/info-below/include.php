<?php

include_once ASHTANGA_CORE_CPT_PATH . '/team/shortcodes/team-list/variations/info-below/info-below.php';
