<?php

include_once ASHTANGA_CORE_PLUGINS_PATH . '/timetable/shortcodes/timetable-events-list/variations/info-below/info-below.php';