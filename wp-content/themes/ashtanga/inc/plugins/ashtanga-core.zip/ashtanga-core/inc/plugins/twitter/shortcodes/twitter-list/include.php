<?php

include_once ASHTANGA_CORE_PLUGINS_PATH . '/twitter/shortcodes/twitter-list/class-ashtangacore-twitter-list-shortcode.php';
