<?php

include_once ASHTANGA_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/helper.php';
include_once ASHTANGA_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/class-ashtangacore-instagram-list-shortcode.php';
