<?php

include_once ASHTANGA_CORE_PLUGINS_PATH . '/instagram/helper.php';
