<?php

include_once ASHTANGA_CORE_INC_PATH . '/core-dashboard/sub-pages/system-info/class-ashtangacore-dashboard-system-info-page.php';
