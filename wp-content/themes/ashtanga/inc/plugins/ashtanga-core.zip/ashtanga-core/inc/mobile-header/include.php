<?php

include_once ASHTANGA_CORE_INC_PATH . '/mobile-header/helper.php';
include_once ASHTANGA_CORE_INC_PATH . '/mobile-header/class-ashtangacore-mobile-header.php';
include_once ASHTANGA_CORE_INC_PATH . '/mobile-header/class-ashtangacore-mobile-headers.php';
include_once ASHTANGA_CORE_INC_PATH . '/mobile-header/template-functions.php';
