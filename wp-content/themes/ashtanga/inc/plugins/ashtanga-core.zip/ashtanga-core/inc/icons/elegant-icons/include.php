<?php

include_once ASHTANGA_CORE_INC_PATH . '/icons/elegant-icons/class-ashtangacore-elegant-icons-pack.php';
