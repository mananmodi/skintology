<?php

include_once ASHTANGA_CORE_INC_PATH . '/search/layouts/covers-header/helper.php';
include_once ASHTANGA_CORE_INC_PATH . '/search/layouts/covers-header/class-ashtangacore-covers-header-search.php';
