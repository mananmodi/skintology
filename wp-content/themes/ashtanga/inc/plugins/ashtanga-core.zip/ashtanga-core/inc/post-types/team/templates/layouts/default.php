<article <?php post_class( 'qodef-team-list-item qodef-e' ); ?>>
	<div class="qodef-e-inner">
		<div class="qodef-e-content">
			<?php
			// Include team single content
			the_content();
			?>
		</div>
	</div>
</article>
