<?php

include_once ASHTANGA_CORE_INC_PATH . '/icons/font-awesome/class-ashtangacore-font-awesome-pack.php';
