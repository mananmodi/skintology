<?php

include_once ASHTANGA_CORE_PLUGINS_PATH . '/timetable/class-ashtangacore-timetable.php';
