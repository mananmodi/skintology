<?php

include_once ASHTANGA_CORE_INC_PATH . '/content/helper.php';
