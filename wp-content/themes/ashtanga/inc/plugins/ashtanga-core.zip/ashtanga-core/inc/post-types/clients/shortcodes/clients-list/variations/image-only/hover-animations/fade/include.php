<?php

include_once ASHTANGA_CORE_CPT_PATH . '/clients/shortcodes/clients-list/variations/image-only/hover-animations/fade/helper.php';
