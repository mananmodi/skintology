<?php

include_once ASHTANGA_CORE_CPT_PATH . '/class-ashtangacore-custom-post-types.php';
