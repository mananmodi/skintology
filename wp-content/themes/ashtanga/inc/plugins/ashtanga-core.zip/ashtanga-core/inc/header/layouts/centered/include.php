<?php

include_once ASHTANGA_CORE_INC_PATH . '/header/layouts/centered/helper.php';
include_once ASHTANGA_CORE_INC_PATH . '/header/layouts/centered/class-ashtangacore-centered-header.php';
include_once ASHTANGA_CORE_INC_PATH . '/header/layouts/centered/dashboard/admin/centered-header-options.php';
include_once ASHTANGA_CORE_INC_PATH . '/header/layouts/centered/dashboard/meta-box/centered-header-meta-box.php';
