<?php

include_once ASHTANGA_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/widget/class-ashtangacore-instagram-list-widget.php';
