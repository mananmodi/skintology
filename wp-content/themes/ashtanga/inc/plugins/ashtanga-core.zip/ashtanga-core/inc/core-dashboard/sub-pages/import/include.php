<?php

include_once ASHTANGA_CORE_INC_PATH . '/core-dashboard/sub-pages/import/class-ashtangacore-dashboard-import-page.php';
include_once ASHTANGA_CORE_INC_PATH . '/core-dashboard/sub-pages/import/class-ashtangacore-dashboard-import.php';
