<?php

include_once ASHTANGA_CORE_CPT_PATH . '/testimonials/shortcodes/testimonials-list/variations/info-below/info-below.php';
