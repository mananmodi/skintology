<?php

include_once ASHTANGA_CORE_INC_PATH . '/blog/shortcodes/blog-list/widget/class-ashtangacore-blog-list-widget.php';
include_once ASHTANGA_CORE_INC_PATH . '/blog/shortcodes/blog-list/widget/class-ashtangacore-simple-blog-list-widget.php';
