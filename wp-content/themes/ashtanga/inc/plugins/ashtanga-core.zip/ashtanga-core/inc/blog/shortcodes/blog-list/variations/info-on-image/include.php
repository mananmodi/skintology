<?php

include_once ASHTANGA_CORE_INC_PATH . '/blog/shortcodes/blog-list/variations/info-on-image/info-on-image.php';
