<?php

include_once ASHTANGA_CORE_PLUGINS_PATH . '/contact-form-7/widgets/contact-form-7/class-ashtangacore-contact-form-7-widget.php';
