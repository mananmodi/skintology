<?php

if ( qode_framework_is_installed( 'elementor' ) ) {
	include_once ASHTANGA_CORE_PLUGINS_PATH . '/elementor/helper.php';
	include_once ASHTANGA_CORE_PLUGINS_PATH . '/elementor/class-ashtangacore-elementor-section-handler.php';
	include_once ASHTANGA_CORE_PLUGINS_PATH . '/elementor/class-ashtangacore-elementor-container-handler.php';
}
