<?php

include_once ASHTANGA_CORE_INC_PATH . '/blog/shortcodes/blog-list/variations/minimal/minimal.php';
