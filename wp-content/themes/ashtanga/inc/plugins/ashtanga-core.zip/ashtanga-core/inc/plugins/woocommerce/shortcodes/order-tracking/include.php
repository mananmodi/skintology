<?php

include_once ASHTANGA_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/order-tracking/class-ashtangacore-order-tracking-shortcode.php';
