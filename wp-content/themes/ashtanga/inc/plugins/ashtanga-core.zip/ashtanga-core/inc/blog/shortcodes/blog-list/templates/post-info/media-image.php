<div class="qodef-e-media">
	<?php
	ashtanga_core_template_part( 'blog/shortcodes/blog-list', 'templates/post-info/image', '', $params );
	?>
</div>
