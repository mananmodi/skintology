<?php

include_once MASTERDS_MEMBERSHIP_INC_PATH . '/widgets/login-opener/class-masterdsmembership-login-opener-widget.php';
