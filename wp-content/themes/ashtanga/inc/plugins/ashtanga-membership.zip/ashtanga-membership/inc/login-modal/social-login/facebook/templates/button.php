<div class="qodef-m-social-login qodef--facebook">
	<button type="submit" class="qodef-m-social-login-btn" data-social="facebook"><?php echo masterds_membership_get_svg_icon( 'facebook' ); ?></button>
</div>
