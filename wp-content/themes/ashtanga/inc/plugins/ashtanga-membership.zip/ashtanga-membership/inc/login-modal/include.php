<?php

include_once MASTERDS_MEMBERSHIP_LOGIN_MODAL_PATH . '/helper.php';

foreach ( glob( MASTERDS_MEMBERSHIP_LOGIN_MODAL_PATH . '/*/include.php' ) as $module ) {
	include_once $module;
}
