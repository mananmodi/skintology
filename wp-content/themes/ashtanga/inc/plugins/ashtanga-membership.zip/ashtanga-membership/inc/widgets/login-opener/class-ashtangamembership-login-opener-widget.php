<?php

if ( ! function_exists( 'masterds_membership_add_author_info_widget' ) ) {
	/**
	 * Function that add widget into widgets list for registration
	 *
	 * @param array $widgets
	 *
	 * @return array
	 */
	function masterds_membership_add_author_info_widget( $widgets ) {
		$widgets[] = 'MasterdsMembership_Login_Opener_Widget';

		return $widgets;
	}

	add_filter( 'masterds_membership_filter_register_widgets', 'masterds_membership_add_author_info_widget' );
}

if ( class_exists( 'QodeFrameworkWidget' ) ) {
	class MasterdsMembership_Login_Opener_Widget extends QodeFrameworkWidget {

		public function map_widget() {
			$this->set_base( 'masterds_membership_login_opener' );
			$this->set_name( esc_html__( 'Masterds Login Opener', 'masterds-membership' ) );
			$this->set_description( esc_html__( 'Login and register membership widget', 'masterds-membership' ) );
			$this->set_widget_option(
				array(
					'field_type'  => 'text',
					'name'        => 'login_opener_margin',
					'title'       => esc_html__( 'Opener Margin', 'masterds-membership' ),
					'description' => esc_html__( 'Insert margin in format: top right bottom left', 'masterds-membership' ),
				)
			);
		}

		public function render( $atts ) {
			$classes   = array();
			$classes[] = is_user_logged_in() ? 'qodef-user-logged--in' : 'qodef-user-logged--out';

			$styles = array();

			if ( ! empty( $atts['login_opener_margin'] ) ) {
				$styles[] = 'margin: ' . $atts['login_opener_margin'];
			}

			$dashboard_template = apply_filters( 'masterds_membership_filter_dashboard_template_name', '' );

			if ( empty( $dashboard_template ) || ! is_page_template( $dashboard_template ) || ( is_page_template( $dashboard_template ) && is_user_logged_in() ) ) { ?>
				<div class="qodef-login-opener-widget <?php echo implode( ' ', $classes ); ?>" <?php qode_framework_inline_style( $styles ); ?>>
					<?php masterds_membership_template_part( 'widgets/login-opener', 'templates/holder' ); ?>
				</div>
				<?php
			}
		}
	}
}
