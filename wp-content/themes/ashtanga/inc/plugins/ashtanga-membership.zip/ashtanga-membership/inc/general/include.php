<?php

foreach ( glob( MASTERDS_MEMBERSHIP_INC_PATH . '/general/dashboard/admin/*.php' ) as $module ) {
	include_once $module;
}

require_once MASTERDS_MEMBERSHIP_INC_PATH . '/general/class-masterdsmembership-page-templates.php';
include_once MASTERDS_MEMBERSHIP_INC_PATH . '/general/helper.php';
