<div class="qodef-m-social-login qodef--twitter">
	<button type="submit" class="qodef-m-social-login-btn" data-social="twitter"><?php echo masterds_membership_get_svg_icon( 'twitter' ); ?></button>
</div>
