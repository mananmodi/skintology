<?php

if ( is_user_logged_in() ) {
	masterds_membership_template_part( 'widgets/login-opener', 'templates/logged-in-content' );
} else {
	masterds_membership_template_part( 'widgets/login-opener', 'templates/logged-out-content' );
}
